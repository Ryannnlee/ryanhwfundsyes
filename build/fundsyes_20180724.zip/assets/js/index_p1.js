"use strict";

$(function () {});